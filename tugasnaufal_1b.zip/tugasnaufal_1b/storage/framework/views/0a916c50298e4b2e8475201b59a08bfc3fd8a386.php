<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>INFOEVENT</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
            html, body {
                background-image: url("oke.jpg");
                background-color:  ;
                color: #F5FFFA;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #F5FFFA;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }

            .bottom {
                margin-bottom: 90px;
            }
        </style>
    </head>
    <div class="links">
                    <a href="https://laravel.com/docs">INFOEVENT!</a>
                    <a href=></a>
                    <a href=></a>
                    <a href=></a>
                    <a href=></a>
                    <a href=></a>
                    <a href=></a>
                    <a href=></a>
                    <a href=></a>
                    <a href=></a>
                    <a href=></a>
                    <a href=></a>
                    <a href=></a>
                    <a href=></a>
                    <a href=></a>
                    <a href="https://laracasts.com">Event</a>
                    <a href="https://laravel-news.com">Cari Event</a>
                    <a href="https://blog.laravel.com">Buat Event</a>
                      <a href="https://nova.laravel.com">Masuk</a>
                    
                </div>
    <body>
        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="content">
                <div class="title m-b-md">
                    #Berangkat Yuk!</div>
                 <div class="links"  > 
                    
                <a >Bagi kalian yang suka nonton atau ikutan event-event seni,budaya,musik,serta apa saja tentang masa kini,kalian dapat mengakses segala informasinya di #INFOEVENT Ajah,ada banyak diskon tiket lohhh,Buruan klik disini!!!</a>

                
            </div>
                <div class="links">
                <a >Baca Selengkapnya...</a>
</div>
                
            
            <div class="bottom">
                    Support By M.Naufal Alwan _ Software/B</div>
                    </div>
                    <div>
        </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\tugasnaufal_1b\resources\views/welcome.blade.php ENDPATH**/ ?>